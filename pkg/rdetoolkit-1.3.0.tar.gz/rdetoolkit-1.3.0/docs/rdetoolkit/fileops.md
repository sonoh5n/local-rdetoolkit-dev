# fileops

## readf_json

::: src.rdetoolkit.fileops.readf_json

## writef_json

::: src.rdetoolkit.fileops.writef_json
