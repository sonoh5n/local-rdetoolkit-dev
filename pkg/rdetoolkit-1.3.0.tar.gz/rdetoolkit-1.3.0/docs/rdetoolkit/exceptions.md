# exceptions

## StructuredError

::: src.rdetoolkit.exceptions.StructuredError

## InvoiceModeError

::: src.rdetoolkit.exceptions.InvoiceModeError

## ExcelInvoiceModeError

::: src.rdetoolkit.exceptions.ExcelInvoiceModeError

## MultiDataTileModeError

::: src.rdetoolkit.exceptions.MultiDataTileModeError

## RdeFormatModeError

::: src.rdetoolkit.exceptions.RdeFormatModeError

## InvoiceSchemaValidationError

::: src.rdetoolkit.exceptions.InvoiceSchemaValidationError

## MetadataValidationError

::: src.rdetoolkit.exceptions.MetadataValidationError
