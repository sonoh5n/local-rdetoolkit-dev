# result

## WorkflowExecutionStatus

::: src.rdetoolkit.models.result.WorkflowExecutionStatus

## WorkflowExecutionResults

::: src.rdetoolkit.models.result.WorkflowExecutionResults

## WorkflowResultManager

::: src.rdetoolkit.models.result.WorkflowResultManager
    options:
            members:
                - add
                - add_status
                - to_json
