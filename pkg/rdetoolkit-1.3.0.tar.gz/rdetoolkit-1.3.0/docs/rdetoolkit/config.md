# config

## parse_config_file

::: src.rdetoolkit.config.parse_config_file

## find_config_files

::: src.rdetoolkit.config.find_config_files

## get_config

::: src.rdetoolkit.config.get_config

## load_config

::: src.rdetoolkit.config.load_config

## is_toml

::: src.rdetoolkit.config.is_toml

## is_yaml

::: src.rdetoolkit.config.is_yaml

## get_pyproject_toml

::: src.rdetoolkit.config.get_pyproject_toml
