# Core Module

> :warning: API documentation is currently under development.

This module provides core functionality for rdetoolkit.

::: src.rdetoolkit.core
    handler: python
    options:
      show_root_heading: true
      members:
        - ManagedDirectory
        - DirectoryOps
