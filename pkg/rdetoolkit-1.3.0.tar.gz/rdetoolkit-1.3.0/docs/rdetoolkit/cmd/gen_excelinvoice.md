# gen_excelinvoice

## GenerateExcelInvoiceCommand

::: src.rdetoolkit.cmd.gen_excelinvoice.GenerateExcelInvoiceCommand
    options:
            members:
                -  invoke
