"""Tests for the processing pipeline architecture."""
