"""Test fixtures for processing pipeline tests."""
