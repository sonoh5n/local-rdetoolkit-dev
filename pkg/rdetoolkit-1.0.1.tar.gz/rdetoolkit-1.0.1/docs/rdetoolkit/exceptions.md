# exceptions

## StructuredError

::: src.rdetoolkit.exceptions.StructuredError

## InvoiceSchemaValidationError

::: src.rdetoolkit.exceptions.InvoiceSchemaValidationError

## MetadataValidationError

::: src.rdetoolkit.exceptions.MetadataValidationError

## catch_exception_with_message

::: src.rdetoolkit.exceptions.catch_exception_with_message

## handle_exception

::: src.rdetoolkit.exceptions.handle_exception

## format_simplified_traceback

::: src.rdetoolkit.exceptions.format_simplified_traceback
