# rdelogger

`rdelogger `is used to collect execution logs of the structuring process.

## get_logger

::: src.rdetoolkit.rdelogger.get_logger

## write_job_errorlog_file

::: src.rdetoolkit.rdelogger.write_job_errorlog_file

## CustomLog

::: src.rdetoolkit.rdelogger.CustomLog
    options:
        members:
            - get_logger
            - _set_handler

## log_decorator

::: src.rdetoolkit.rdelogger.log_decorator
