def read_from_json_file(invoice_file_path: RdeFsPath) -> dict[str, Any]:  # pragma: no cover
    """A function that reads json file and returns the json object.

    Args:
        invoice_file_path (RdeFsPath): The path to the JSON file.

    Returns:
        dict[str, Any]: The parsed json object.
    """
    enc = CharDecEncoding.detect_text_file_encoding(invoice_file_path)
    with open(invoice_file_path, encoding=enc) as f:
        return json.load(f)
