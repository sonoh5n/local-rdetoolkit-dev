# workflows

In `workflows`, modules necessary for building the structuring process are defined.

## check_files

::: src.rdetoolkit.workflows.check_files

## generate_folder_paths_iterator

::: src.rdetoolkit.workflows.generate_folder_paths_iterator

## run

::: src.rdetoolkit.workflows.run
