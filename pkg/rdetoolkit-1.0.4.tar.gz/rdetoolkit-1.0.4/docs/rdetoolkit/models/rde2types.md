# rde2types

In `rde2types`, various data classes and custom types used in RDE are defined.

## RdeFormatFlags

::: src.rdetoolkit.models.rde2types.RdeFormatFlags

## RdeInputDirPaths

::: src.rdetoolkit.models.rde2types.RdeInputDirPaths

## RdeOutputResourcePath

::: src.rdetoolkit.models.rde2types.RdeOutputResourcePath

## Name

::: src.rdetoolkit.models.rde2types.Name

## Schema

::: src.rdetoolkit.models.rde2types.Schema

## MetadataDefJson

::: src.rdetoolkit.models.rde2types.MetadataDefJson

## ValueUnitPair

::: src.rdetoolkit.models.rde2types.ValueUnitPair
