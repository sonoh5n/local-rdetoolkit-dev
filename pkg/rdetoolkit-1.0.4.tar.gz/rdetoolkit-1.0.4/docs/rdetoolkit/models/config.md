# config

## Config

::: src.rdetoolkit.models.config.Config

## SystemSettings

::: src.rdetoolkit.models.config.SystemSettings

## MultiDataTileSettings

::: src.rdetoolkit.models.config.MultiDataTileSettings
