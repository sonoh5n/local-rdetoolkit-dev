# metadata

In `metadata`, models for validating metadata.json used in RDE are defined.

## MetadataItem

::: src.rdetoolkit.models.metadata.MetadataItem

### ValidableItems

::: src.rdetoolkit.models.metadata.ValidableItems

### MetaValue

::: src.rdetoolkit.models.metadata.MetaValue

### Variable

::: src.rdetoolkit.models.metadata.Variable
