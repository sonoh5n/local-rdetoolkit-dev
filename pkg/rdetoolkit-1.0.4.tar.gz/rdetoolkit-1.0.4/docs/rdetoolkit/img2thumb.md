# img2thumb

In img2thumb, processes related to representative images (thumbnail images) are defined.

## copy_images_to_thumbnail

::: src.rdetoolkit.img2thumb.copy_images_to_thumbnail

## resize_image

::: src.rdetoolkit.img2thumb.resize_image
