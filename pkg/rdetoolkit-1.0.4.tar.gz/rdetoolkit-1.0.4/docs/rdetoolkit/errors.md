# errors

## catch_exception_with_message

::: src.rdetoolkit.errors.catch_exception_with_message

## format_simplified_traceback

::: src.rdetoolkit.errors.format_simplified_traceback

## handle_exception

::: src.rdetoolkit.errors.handle_exception

## handle_and_exit_on_structured_error

::: src.rdetoolkit.errors.handle_and_exit_on_structured_error

## handle_generic_error

::: src.rdetoolkit.errors.handle_generic_error

## write_job_errorlog_file

::: src.rdetoolkit.errors.write_job_errorlog_file
