# rdelogger

`rdelogger `is used to collect execution logs of the structuring process.

## LazyFileHandler

::: src.rdetoolkit.rdelogger.LazyFileHandler
    options:
        members:
            - _ensure_handler
            - emit

## get_logger

::: src.rdetoolkit.rdelogger.get_logger

## CustomLog

::: src.rdetoolkit.rdelogger.CustomLog
    options:
        members:
            - get_logger
            - _set_handler

## log_decorator

::: src.rdetoolkit.rdelogger.log_decorator
