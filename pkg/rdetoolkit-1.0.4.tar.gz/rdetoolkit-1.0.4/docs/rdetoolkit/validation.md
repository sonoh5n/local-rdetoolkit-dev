# validation

The `validation.py` defines classes and functions for validating a group of template files.

## MetadataValidator

::: src.rdetoolkit.validation.MetadataValidator
    options:
        members:
            - validate

## metadata_validate

::: src.rdetoolkit.validation.metadata_validate

## InvoiceValidator

::: src.rdetoolkit.validation.InvoiceValidator
    options:
        members:
            - validate

## invoice_validate

::: src.rdetoolkit.validation.invoice_validate
